import os
import re
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("markdown_file")
parser.add_argument("--output-dir", default="sections")
args = parser.parse_args()

os.makedirs(args.output_dir, exist_ok=True)

with open(args.markdown_file) as f:
    content = f.read()

sections = re.split(r"\n(?=## )", content)

for i, sec in enumerate(sections):
    if sec.startswith("# "):
        continue

    title = sec.split("\n")[0].replace("## ", "")
    filename = f"{i:02d}_{re.sub(r'[^a-zA-Z0-9]+','_',title).lower()}.md"

    with open(os.path.join(args.output_dir, filename), "w") as out:
        out.write(sec.strip())

print("Sections written to", args.output_dir)