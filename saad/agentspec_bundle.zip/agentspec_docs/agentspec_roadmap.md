# AgentSpec Roadmap Toward AgentOS and Full ADLC

## 1. Adoption and Developer Experience
Focus on making AgentSpec installable and usable in minutes.
Provide packaged releases, Homebrew install, Docker images, and starter templates.

Deliver runnable examples like:
- support bot
- RAG assistant
- research swarm
- incident-response agent
- GPU batch agent
- multi-agent router

## 2. Kubernetes Operator and Control Plane
Introduce an AgentSpec operator with CRDs:

- Agent
- Task
- Session
- Workflow
- MemoryClass
- ToolBinding
- Policy
- Schedule
- EvalRun
- Release

Replace simple manifest generation with reconciliation-driven lifecycle management.

## 3. Distributed State and Reconciliation
Move beyond `.agentspec.state.json`.

Support backends:

- local JSON (dev)
- SQLite (single-node)
- Postgres (production)

The operator reconciles desired state from this control-plane database.

## 4. Full Agent Development Lifecycle (ADLC)

Lifecycle stages:

Design → Develop → Test → Evaluate → Package → Release → Deploy → Observe → Improve → Retire

Capabilities:

- replayable sessions
- dataset versioning
- regression testing
- promotion pipelines
- experiment tracking

## 5. Native Scheduling Layer

Add scheduling primitives to IntentLang:

- queues
- priority
- deadlines
- parallelism limits
- placement rules
- retries
- resource budgets

Scheduling must be a **core subsystem**.

## 6. Native Gang Scheduling

Support a scheduling DSL:

schedule:
  queue: research
  priority: high
  gang:
    min_members: 4
    timeout: 60s

Backends:

- local scheduler
- Kubernetes native gang scheduling
- Kueue
- Volcano

## 7. Dependency Strategy

AgentSpec should own:

- DSL
- packaging
- operator
- ADLC
- scheduler abstraction
- evaluation engine
- governance workflows

External integrations remain pluggable:

- models
- vector stores
- identity providers
- telemetry sinks

## 8. Adoption Wedge

Position AgentSpec as:

GitOps for agents
+ Kubernetes-native scheduling
+ full ADLC lifecycle

Focus on enterprise-grade:

- governance
- auditability
- reproducibility

## 9. Phased Implementation Plan

Phase 1:
- packaging
- documentation
- starter examples

Phase 2:
- operator
- CRDs

Phase 3:
- ADLC lifecycle features

Phase 4:
- scheduler service
- scheduling DSL

Phase 5:
- gang scheduling support

Phase 6:
- full AgentOS control plane